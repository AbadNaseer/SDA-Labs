package lab3;

import java.util.ArrayList;
import java.util.List;

public class Department {
	public int Id;
	public String Name;
	List<String>Course_list=new ArrayList<String>();
	public Department(int i, String n)
	{
		this.Id=i;
		this.Name=n;
	}
	public void SetCourses(String s)
	{
		this.Course_list.add(s);
	}
	public void Search(String s)
	{
		for(String s1:Course_list)
		{
			if(s1==s)
			{
				System.out.println(s+" is present in the department");
			}
			else
			{
				System.out.println(s+" is not present");
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Department> DeptList=new ArrayList<Department>();
		Department D1=new Department(1, "CS");
		Department D2=new Department(2, "SE");
		Department D3=new Department(3, "EE");
		Department D4=new Department(4, "ME");
		Department D5=new Department(5, "AI");
		DeptList.add(D1);
		DeptList.add(D2);
		DeptList.add(D3);
		DeptList.add(D4);
		DeptList.add(D5);
		//setting the name of the department course to data structures
		D1.SetCourses("Data Structures");
		//for searching the course in the list 
		D1.Search("Data Structures");
		//for iterating the list
		for(Department d:DeptList)
		{
			System.out.println("ID of the Department: "+d.Id+" Name of the Department: "+ d.Name);
		}
		//for deleting the departments 
		for(int i=0; i<DeptList.size(); i++)
		{
			DeptList.remove(i);
		}
		//for converting array list to array
		Object[] dept = DeptList.toArray();
	}

}
//Create a class Department that has the following data members:
//Id, Name, an array list of courses.
// Create an array list of Department.
// Add 5 departments into that array list.
// Sets the name of any department’s course name to “Data Structures”.
// Search whether a certain course is present in the list or not.
// Iterate the list using a for loop.
// Deletes the entire department’s array list.
// Converts the array list to an array.