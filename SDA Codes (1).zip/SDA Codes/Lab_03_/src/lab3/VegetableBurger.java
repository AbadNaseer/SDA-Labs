package lab3;

public class VegetableBurger extends Burger{
	public void VegtTaste()
	{
		System.out.print("My Taste is good");
	}
	public void add()
	{
		System.out.println("Vegetable Burger Added");
	}
}
