package lab3;

public class Burger extends Meal{
	public String taste;
	public Burger()
	{
		this.taste="Good";
	}
	public void add()
	{
		System.out.println("Burger Added");
	}
}
