package lab3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Course {
	private String Id;
	public String Name;
	public int CreditHours;
	public int Type;//(Core/Elective).
	public String GetId()
	{
		return this.Id;
	}
	public Course(String id, String n, int ch)
	{
		this.Id=id;
		this.Name=n;
		this.CreditHours=ch;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//students
		Student S1=new Student(1, "Abad", 20, 3.5);
		Student S2=new Student(2, "Ali", 89, 2.5);
		Student S3=new Student(3, "Ahmad", 32, 4.0);
		Student S4=new Student(4, "Usman", 54, 2.3);
		Student S5=new Student(5, "Iqbal", 11, 2.7);
		//courses
		Course c1=new Course("1", "SDA", 3);
		Course c2=new Course("2", "SDA Lab ", 1);
		Course c3=new Course("3", "SRE", 3);
		Course c4=new Course("4", "Intro. to SE", 3);
		Course c5=new Course("5", "HCI", 3);
		Map<String, List<Student>> map = new HashMap<String, List<Student>>();
		
		map.put(c1.GetId(), new ArrayList<Student>(Arrays.asList(S1, S2, S3, S4, S5))); 
		map.put(c2.GetId(), new ArrayList<Student>(Arrays.asList(S1, S2, S3, S4, S5))); 
		map.put(c3.GetId(), new ArrayList<Student>(Arrays.asList(S1, S2, S3, S4, S5))); 
		map.put(c4.GetId(), new ArrayList<Student>(Arrays.asList(S1, S2, S3, S4, S5))); 
		map.put(c5.GetId(), new ArrayList<Student>(Arrays.asList(S1, S2, S3, S4, S5))); 
		S5.name="Ali Naeem";
//		for (Entry<String, List<Student>> entry : map.entrySet()) {
//	        for(Student ss : entry.getValue()){
//	        	if(c2.GetId()=="2")
//	        	{
//	        		System.out.println(ss);
//	        	}
//	        }
//	        System.out.println();
//	    }
	}

}
//Create a class Course that has the following data members:
//Id, Name, credit hours, Type (Core/Elective).
// Create a hash table. Key will be the course id and value will be the array list of
//students.
// Add 5 records in that table.
// Sets the name of the last student.
// Print all the students who are taking a course with id = 2.
// Delete 3 rd element from the table.
// Iterate the table using a for loop.


//import java.util.*;  
//class Hashtable1{  
// public static void main(String args[]){  
//  Hashtable<Integer,String> hm=new Hashtable<Integer,String>();  
//  
//  hm.put(100,"Amit");  
//  hm.put(102,"Ravi");  
//  hm.put(101,"Vijay");  
//  hm.put(103,"Rahul");  
//  
//  for(Map.Entry m:hm.entrySet()){  
//   System.out.println(m.getKey()+" "+m.getValue());  
//  }  
// }  
//} 