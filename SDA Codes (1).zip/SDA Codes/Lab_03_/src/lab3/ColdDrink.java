package lab3;

public class ColdDrink extends Meal{
	public String taste;
	public ColdDrink()
	{
		this.taste="Good";
		System.out.print("My Taste is good");
	}
	public void add()
	{
		System.out.println("Cold Drink Added");
	}
}
