package lab3;

public class Coke extends ColdDrink{
	public void CokeTaste()
	{
		System.out.print("My Taste is good");
	}
	public void add()
	{
		System.out.println("Coke Added");
	}
}
