package lab3;

public interface Item {
	public void add();
}
