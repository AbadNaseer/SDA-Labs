package lab3;

import java.util.ArrayList;
import java.util.List;

public class MealBuilderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Meal>list=new ArrayList<Meal>();
		
		Meal m=new Burger();
		m.add();
		list.add(m);
		
		ColdDrink c=new Pepsi();
		c.add();
		list.add(m);
	}

}
