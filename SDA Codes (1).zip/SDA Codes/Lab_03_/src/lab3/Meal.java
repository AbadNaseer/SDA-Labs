package lab3;

import java.util.ArrayList;
import java.util.List;

public abstract class Meal implements Item{
	public Meal()
	{
			System.out.print("I am Meal");
	}
	public void add()
	{
		System.out.print("Meal Added");
	}
}
