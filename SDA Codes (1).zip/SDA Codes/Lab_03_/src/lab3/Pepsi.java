package lab3;

public class Pepsi extends ColdDrink{
		public void PepsiTaste()
		{
			System.out.print("My Taste is good");
		}
		public void add()
		{
			System.out.println("Pepsi Added");
		}
}
