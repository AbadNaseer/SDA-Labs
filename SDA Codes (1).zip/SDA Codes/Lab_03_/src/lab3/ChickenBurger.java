package lab3;

public class ChickenBurger extends Burger{
	public void ChickenTaste()
	{
		System.out.println("My Taste is good");
	}
	public void add()
	{
		System.out.println("Chicken Burger Added");
	}
}
