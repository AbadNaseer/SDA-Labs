package i201815_Abad_Naseer_Q_SDA_Lab_02_;

public class Professor extends Person {
	public String Course_Taught[]=new String[5] ;
	public String AddCourse;
	public String DeleteCourse;
	public Professor(String n, String Add) {
		super(n, Add);
	}
	public Professor(String n, String Add, String ct, String ad, String dc) {
		super(n, Add);
		this.Course_Taught[0]=ct;
		this.AddCourse=ad;
		this.DeleteCourse=dc;
	}
	public void CourseTaught(String c[])
	{
		for(int i=0; i<5; i++)
		{
			
		}
	}
	public void addCourse(String a)
	{
		
	}
	public void RemoveCourse(String a)
	{
		
	}

}
//Suppose that we are required to model students and professors in our application. We can define a
//superclass called Person to store common properties such as name and address, and subclasses Student
//and professors for their specific properties. For students, we need to maintain the courses taken and
//their respective grades; add a course with grade, print all courses taken. Assume
//that a student takes no more than 30 courses for the entire program. For professors, we need to
//maintain the courses taught currently, and able to add or remove a course taught. Assume that a
//professor teaches not more than 5 courses concurrently.