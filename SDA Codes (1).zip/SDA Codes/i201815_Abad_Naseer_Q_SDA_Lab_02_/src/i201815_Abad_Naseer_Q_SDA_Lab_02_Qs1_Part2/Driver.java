package i201815_Abad_Naseer_Q_SDA_Lab_02_;

public class Driver {

	public static void main(String[] args) {
	Student s=new Student("Abad Naseer", "G-13/2", "SDA", "A");
	s.AddCourseWithGrade("SDA", "A");//add course with grade
	s.PrintCoursesAndGrades();
	Professor P=new Professor("Obaid", "G-11/2", "SDA", "SDA Lab", "SDA Lab");
	}
}