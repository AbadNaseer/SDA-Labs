package i201815_Abad_Naseer_Q_SDA_Lab_02_;

public class Student extends Person {
	public String Courses_Taken[]=new String[30];
	public String Grades[]=new String[30];
	//constructor
	public Student(String Name, String Address, String ct, String g) {
	super(Name, Address);
	this.Courses_Taken[0]=ct;
	this.Grades[0]=g;
	}
	public void AddCourseWithGrade( String ct, String g)
	{
		for(int i=1; i<30; i++)
		{
			this.Courses_Taken[i]=ct;
			this.Grades[i]=g;
		}
		
	}
	public void PrintCoursesAndGrades()
	{
		System.out.println("Name of the Student:"+Name);
		System.out.println("Courses Taken:"+Courses_Taken[0]);
		System.out.println("Grade in SDA: "+Grades[0]);
	}
}
//Suppose that we are required to model students and professors in our application. We can define a
//superclass called Person to store common properties such as name and address, and subclasses Student
//and professors for their specific properties. For students, we need to maintain the courses taken and
//their respective grades; add a course with grade, print all courses taken. Assume
//that a student takes no more than 30 courses for the entire program. For professors, we need to
//maintain the courses taught currently, and able to add or remove a course taught. Assume that a
//professor teaches not more than 5 courses concurrently.




