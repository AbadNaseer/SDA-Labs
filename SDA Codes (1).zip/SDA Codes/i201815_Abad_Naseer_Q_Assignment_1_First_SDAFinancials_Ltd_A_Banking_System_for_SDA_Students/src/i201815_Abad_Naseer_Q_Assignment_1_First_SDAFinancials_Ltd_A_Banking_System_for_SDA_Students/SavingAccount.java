package i201815_Abad_Naseer_Q_Assignment_1_First_SDAFinancials_Ltd_A_Banking_System_for_SDA_Students;

import java.util.Scanner;

public class SavingAccount extends Accounts{
	public SavingAccount(String s)
	{
		super(s);
	}
	public void OpenAccount(String an)
	{
		System.out.println("Account Opening: ");
		System.out.println("Deposit atleast 100/= to Open an account: ");
		Scanner S=new Scanner(System.in);
		double i=S.nextDouble();
		//S.close();
		if(i>=100)
		{
		String date=UniqueNumberGenerator.generateUniqueNumber();
		Transactions Transaction=new Transactions(AccountNumber, date);
		TransactionsList.add(Transaction);
		System.out.println("Funds deposited!\n");
		}		
	}
	public void DeleteAccount(String an)
	{
		System.out.println("Removing an account: ");
		if(this.AccountNumber.matches(an))
		{
			Accounts Account=new CurrentAccount(an);
			Account.TransactionsList.clear();
			System.out.println("Account Removed Sucessfully: ");
		}
	}
	public String ShowAccountHolder()
	{
	return UsrLgn.GetId()+UsrLgn.GetAddress();
	} 
	public void ShowStatus()
	{
		for(Transactions Transaction: TransactionsList)
		{
			double Amount=Transaction.GetBalance();
			double Sum=0;
			Sum=Sum+Amount;
			if(Sum<0)
			{
				System.out.println("We are Sorry! Your Account is Dormant: ");
				System.out.println("Visit Branch or Call at Bank Official NUmber, Thank you, ");
			}
			else
			{
				System.out.println("Congrats! Your Account is Active: ");
			}
		}
	}
	public void ShowStatement()
	{
		System.out.println("Total Balance: ");
		for(Transactions T:TransactionsList)
		{
			System.out.println("Transactions Date"+T.GetDate());
		}
	}
	public void AddTransaction(Transactions T)
	{
		TransactionsList.add(T);
	}
}
