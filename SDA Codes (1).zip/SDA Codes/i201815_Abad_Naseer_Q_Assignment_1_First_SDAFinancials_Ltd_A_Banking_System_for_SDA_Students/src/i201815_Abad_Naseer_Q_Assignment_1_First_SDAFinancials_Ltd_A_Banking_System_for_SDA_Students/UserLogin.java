package i201815_Abad_Naseer_Q_Assignment_1_First_SDAFinancials_Ltd_A_Banking_System_for_SDA_Students;

import java.util.ArrayList;
import java.util.List;

public class UserLogin {
	private String IdNumber;//ID of the student
	private String Address;//address of the student
	private Accounts Account[]=new Accounts[3];//accounts of the student
	//private static_int i=0;
	public UserLogin(String add, String idn)
	{
		this.Address=add;
		this.IdNumber=idn;
	}
	public void SetUserAddress(String add)
	{
		this.Address=add;
	}
	
	public String GetAddress()
	{
		return this.Address;
	}
	public String GetId()
	{
		return this.IdNumber;
	}
	public void SetAccount(Accounts A, int index)
	{
		this.Account[index]=A[index];
	}
//	public void CreateAccount()
//	{
//			Scanner scanner = new Scanner(System.in);
//			System.out.println("Enter 1. For Saving Account: ");
//			System.out.println("Enter 2. For Current Account: ");
//			int Input=scanner.nextInt();
//			scanner.close();
//			if(i<=2)
//			{	
//			switch (Input)
//			{
//			case 1:
//				String UniqueNumber=UniqueNumberGenerator.generateUniqueNumber();
//				Account[i]=new SavingAccount(UniqueNumber);
//				
//			case 2:
//			String UniqueNumber1=UniqueNumberGenerator.generateUniqueNumber();
//			Account[i]=new SavingAccount(UniqueNumber1);
//			}
//			i++;
//		}
//			
//	}
//	public Accounts GetAccount(String ii)
//	{
//		int num = Integer.parseInt(ii);
//		return this.Account[num];
//	}
}
//User Management : Modifications to information of each account holder. For each account holder,
//their university ID number, and Address is recorded by the bank. 
//Bank customers may ask for this information to be updated.