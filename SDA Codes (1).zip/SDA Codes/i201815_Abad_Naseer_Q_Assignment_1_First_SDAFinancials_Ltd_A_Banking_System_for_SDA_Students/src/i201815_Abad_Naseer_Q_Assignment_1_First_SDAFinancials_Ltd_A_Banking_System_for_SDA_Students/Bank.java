package i201815_Abad_Naseer_Q_Assignment_1_First_SDAFinancials_Ltd_A_Banking_System_for_SDA_Students;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Bank {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("-----------------Welcome to Banking Management System---------------------");
		System.out.println("Press 1. For Login:");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//Scanner Input=new Scanner(System.in);
		String Press=br.readLine();
		System.out.println(Press);
		List <UserLogin>UserList=new ArrayList<UserLogin>();
		if(Press.matches("1"))
		{
			String ID=UniqueNumberGenerator.generateUniqueNumber();//Id of the student
			
			System.out.println("Login Page Opened: ");
			System.out.println("Enter Your Address: ");
	    	String Address="";
	    	Address=br.readLine();
	    	System.out.println(Address+" Address Entered: ");
	    	String AccountNumbr=UniqueNumberGenerator.generateUniqueNumber();//Account Number of the student 
	    	
	    	UserLogin User=new UserLogin(Address, ID);
	    	UserList.add(User);
				while(Press!="7")
				{
				
				System.out.println("User has been successfully Logged in: ");
				System.out.println("-----------------Features---------------------");
				System.out.println("Press 1. Create a Bank Account:");
				System.out.println("Press 2. Delete a Bank account:");
				System.out.println("Press 3. Deposit Fund into an Account:");
				System.out.println("Press 4. Withdraw Fund from an Account:");
				System.out.println("Press 5. Print Statement of the Account:");
				System.out.println("Press 6. Check Account Status dormant/Active:");
				System.out.println("Press 7. To Exit"); 
				String Num1=br.readLine();
				switch (Num1)
				{
				case "1":
					System.out.println("Enter 1. For Saving Account: ");
					System.out.println("Enter 2. For Current Account: ");
					String Press1;
					Press1=br.readLine();
					//System.out.print(Press1);
					if(Press1.matches("1"))
					{
						Accounts Account=new SavingAccount(AccountNumbr);
						Account.OpenAccount(AccountNumbr);
						User.SetAccount(Account, 0);
						
						break;
					}
					else if(Press1.matches("2"))
					{
						Accounts Account1=new CurrentAccount(AccountNumbr);
						Account1.OpenAccount(AccountNumbr);
						User.SetAccount(Account1);
						break;
					}
					
				case "2":
					Accounts Account=new SavingAccount(AccountNumbr);
					Account.DeleteAccount(AccountNumbr);
					break;
				case "3":
					String Date;
					System.out.print("Enter Date:");
					Date=br.readLine();
					System.out.print("Enter Money to deposit:");
					int Money=br.read();
					Transactions Transaction=new Transactions(AccountNumbr, Date);
					Transaction.Deposit(Money);	
					System.out.print("Money deposited sucessfully:");
					break;
				case "4":
					String Date1;
					System.out.print("Enter Date:");
					Date1=br.readLine();
					System.out.print("Enter Money to Withdraw:");
					int Money1=br.read();
					Transactions Transaction1=new Transactions(AccountNumbr, Date1);
					Transaction1.WithDraw(Money1);
					System.out.print("Amount Withdraw sucessfully:");
					
				case "5":
				case "6":
				
				case "7":
					break;
				}
				}
			}
	else
	{
		System.out.println("Wrong Number Pressed: ");
	}

	//	Input.close();
}
}