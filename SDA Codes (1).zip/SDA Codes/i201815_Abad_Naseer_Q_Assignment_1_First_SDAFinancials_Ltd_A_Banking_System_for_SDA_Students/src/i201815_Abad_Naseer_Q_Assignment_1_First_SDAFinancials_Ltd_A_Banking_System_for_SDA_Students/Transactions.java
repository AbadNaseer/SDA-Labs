package i201815_Abad_Naseer_Q_Assignment_1_First_SDAFinancials_Ltd_A_Banking_System_for_SDA_Students;

public class Transactions {
	private Accounts Acc;
	private String AccountID;//actually account number
	private String Date;
	private double Trans;
	public Transactions(String ac, String d)
	{
		this.AccountID=ac;
		this.Date=d;
		this.Trans=0;
	}
	public void SetAccountNumber(String aid, String d)
	{
		this.AccountID=aid;
		this.Date=d;
		if(AccountID.matches(Acc.GetAccountNumber()))
		{
			System.out.println("Date: "+this.Date);
			Acc.ShowAccountHolder();
			
		}
	}
	public double WithDraw(double t)
	{
		this.Trans+=t;
		return this.Trans=t;
	}
	public double Deposit(double t)
	{
		this.Trans-=t;
		return this.Trans=t;
	}
	public double GetBalance()
	{
		return this.Trans;
	}
	public String GetDate()
	{
		return this.Date;
	}
}
//3. Transactions : Bank supports usual transactions of withdraw and deposit. 
//Additionally, bank keeps track of each transaction that takes place. 
//This can be using a "Transaction Ledger" class (implemented by you of course).
//The ledger should support the functionality of locating transactions
//based on Account ID, or Account ID and Date. Each transaction object
//should also record the Date and time of transaction.