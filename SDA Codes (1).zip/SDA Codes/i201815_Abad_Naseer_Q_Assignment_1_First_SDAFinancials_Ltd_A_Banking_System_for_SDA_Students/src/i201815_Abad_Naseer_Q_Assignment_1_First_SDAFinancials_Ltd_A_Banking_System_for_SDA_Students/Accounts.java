package i201815_Abad_Naseer_Q_Assignment_1_First_SDAFinancials_Ltd_A_Banking_System_for_SDA_Students;

import java.util.ArrayList;
import java.util.List;

abstract class Accounts {
	protected String AccountNumber;
	protected UserLogin UsrLgn;
	List <Transactions> TransactionsList=new ArrayList<Transactions>();
	public Accounts(String a)
	{
		this.AccountNumber=a;
	}
	public String GetAccountNumber()
	{
		return this.AccountNumber;
	}
	public abstract void OpenAccount(String an);
	public abstract void DeleteAccount(String an);
	public abstract String ShowAccountHolder();
	public abstract void ShowStatus();
	public abstract void ShowStatement();
	public abstract void AddTransaction(Transactions T);
}
//5. Account Types : Bank support Saving and Current Accounts. Current accounts can also be owned jointly. 
//That is, more than one person may be owner of an account.
//Also, there is a small penalty of 0.01 % of withdraw amount when taking funds from a Saving Account