package i201815_Abad_Naseer_Q_SDA_Lab_04;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class StudentDataBase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student S=new Student("Abad Naseer", "3.2", "20i-1815", 20);
		Student S1=new Student("Ali", "3.0", "20i-1214", 21);
		try {
		      File file = new File("Student.txt");
		      if (!file.exists()) {
		        file.createNewFile();
		      }
		      FileWriter StudentWriter = new FileWriter(file.getAbsoluteFile());
		      BufferedWriter bufferedWriter = new BufferedWriter(StudentWriter);
		      bufferedWriter.write(S.GetName());
		      bufferedWriter.write(S.GetGPA());
		      bufferedWriter.write(S.GetRollNumber());
		      bufferedWriter.write(S.GetAge());
		      bufferedWriter.newLine();
		      //2nd obj
		      bufferedWriter.write(S1.GetName());
		      bufferedWriter.write(S1.GetGPA());
		      bufferedWriter.write(S1.GetRollNumber());
		      bufferedWriter.write(S1.GetAge());
		      bufferedWriter.close();
		      System.out.println("Data has been written to the file.");
		      BufferedReader ReadStudent=new BufferedReader(new FileReader("Student.txt"));
	    	  String line;
		      while((line=ReadStudent.readLine())!=null)
		      {
		    	  System.out.println(line);
		      }
		    }
			catch (IOException e) {
		      e.printStackTrace();
		    }
		
	}

}
