package i201815_Abad_Naseer_Q_SDA_Lab_04;

public class Student {
	private String Name;
	private String GPA;
	private String RollNumber;
	private int age;
	public Student(String n, String gpa, String rn, int a)
	{
		this.Name=n;
		this.GPA=gpa;
		this.RollNumber=rn;
		this.age=a;
	}
	public String GetName()
	{
		return this.Name;
	}
	public String GetGPA()
	{
		return this.GPA;
	}
	public String GetRollNumber()
	{
		return this.RollNumber;
	}
	public int GetAge()
	{
		return this.age;
	}
}
//Consider a class Student with the following attributes: –
//Name, GPA, Roll Number, age.
//Write a program that reads and writes student objects on to a file.