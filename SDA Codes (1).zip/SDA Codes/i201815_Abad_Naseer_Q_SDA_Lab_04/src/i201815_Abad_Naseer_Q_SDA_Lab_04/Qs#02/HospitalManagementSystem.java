package i201815_Abad_Naseer_Q_SDA_Lab_04;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HospitalManagementSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method s		
		//// Add records of doctor, patient and nurses.
		List<Doctor>DoctorList=new ArrayList<Doctor>();
		
		Doctor Abad=new Doctor("Abad", "G-13/2");//doctor 
		DoctorList.add(Abad);
		//Ward details
		Ward OPD=new Ward("1");
		Patient Ali=new Patient("Ali", OPD);//patient
		//Nurse
		Nurse Hania=new Nurse("Hania","Day Duty", OPD);
		//Add appointments of patient to doctor
		Abad.AddAppointMent(Ali);
		// delete a doctor
		DoctorList.remove(Abad);
		
		try {
		      File file = new File("Hospital.txt");
		      if (!file.exists()) {
		        file.createNewFile();
		      }
		      FileWriter HospitalWriter = new FileWriter(file.getAbsoluteFile());
		      BufferedWriter bufferedWriter = new BufferedWriter(HospitalWriter);
		      //write doctor 
		      bufferedWriter.write(Abad.GetDoctorName());
		      bufferedWriter.write(Abad.GetOffice());
		      bufferedWriter.newLine();
		      //write patient 
		      bufferedWriter.write(Ali.GetPatientName());
		      bufferedWriter.write(Ali.GetWard());
		      bufferedWriter.newLine();
		      //write nurse
		      bufferedWriter.write(Hania.GetNurseName());
		      bufferedWriter.write(Hania.GetDuty());
		      bufferedWriter.write(Hania.GetWard());
		      //2nd obj
		      System.out.println("Data has been written to the file.");
		      BufferedReader ReadHospital=new BufferedReader(new FileReader("Hospital.txt"));
	    	  String line;
		      while((line=ReadHospital.readLine())!=null)
		      {
		    	  System.out.println(line);
		      }
		      ReadHospital.close();
		    }
			catch (IOException e) {
		      e.printStackTrace();
		    }
		System.out.println("Doctor Name:"+Abad.GetDoctorName());
		System.out.println("Doctor Office:"+Abad.GetOffice());
		System.out.println("Patient Name:"+Ali.GetPatientName());
		System.out.println("Patient Ward:"+Ali.GetWard());
		System.out.println("Nurse Name:"+Hania.GetNurseName());
		System.out.println("Nurse Duty Time:"+Hania.GetDuty());
		System.out.println("Nurse Ward Number:"+Hania.GetWard());
	}

}
