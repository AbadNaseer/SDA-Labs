package i201815_Abad_Naseer_Q_SDA_Lab_04;

import java.util.ArrayList;
import java.util.List;

public class Ward {
	private String ID; 
	List <Patient> PatientList=new ArrayList<Patient>();
	List <Nurse> NurseList=new ArrayList<Nurse>();
	public Ward(String id)
	{
		this.ID=id;
	}
	public String GetId()
	{
		return this.ID;
	}
}
