package i201815_Abad_Naseer_Q_SDA_Lab_04;

public class Consultant extends Doctor{
	private int Salary;
	public Consultant(String a, String b, int s)
	{
		super(a, b);
		this.Salary=s;
	}
	public int GetSallary()
	{
		return this.Salary;
	}
}
