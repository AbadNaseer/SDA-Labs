package i201815_Abad_Naseer_Q_SDA_Lab_04;

import java.util.ArrayList;
import java.util.List;

public class Doctor {
	private String DoctorName;
	private String Office;
	List <Patient>PatientList=new ArrayList<Patient>();
	public Doctor(String dn, String o)
	{
		this.DoctorName=dn;
		this.Office=o;
	}
	public String GetDoctorName()
	{
		return this.DoctorName;
	}
	public String GetOffice()
	{
		return this.Office;
	}
	public void AddAppointMent(Patient P)
	{
		PatientList.add(P);
	}
}
//In the hospital there are number of doctors, a few of which hold the position of consultant.
//Every consultant has a specialty. A patient may receive treatment from more than one
//doctor depending on the type of complaint(s) the patient may have.