package i201815_Abad_Naseer_Q_SDA_Lab_04;

import java.util.ArrayList;
import java.util.List;

public class Patient {
	private String PatientName;
	private Ward ward;
	List <Doctor> PatientList=new ArrayList<Doctor>();
	public Patient(String pn, Ward d)
	{
		this.PatientName=pn;
		this.ward=d;
	}
	public String GetPatientName()
	{
		return this.PatientName;
	}
	public String GetWard()
	{
		return this.ward.GetId();
	}
}
