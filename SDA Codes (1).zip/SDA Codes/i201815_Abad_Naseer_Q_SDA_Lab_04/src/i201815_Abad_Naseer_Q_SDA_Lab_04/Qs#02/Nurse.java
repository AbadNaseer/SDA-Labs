package i201815_Abad_Naseer_Q_SDA_Lab_04;

public class Nurse {
	private String Name;
	private String duty;
	private Ward ward;
	public Nurse(String n, String d, Ward w)
	{
		this.Name=n;
		this.duty=d;
		this.ward=w;
	}
	public String GetNurseName()
	{
		return this.Name;
	}
	public String GetWard()
	{
		return this.ward.GetId();
	}
	public String GetDuty()
	{
		return this.duty;
	}
}
