import java.util.ArrayList;
import java.util.List;

public class Student {
	public int id; 
	public String name;
	public int roll_number;
	public double Gpa;
	Student(int i, String n, int rn, double g)
	{
		this.id=i;
		this.name=n;
		this.roll_number=rn;
		this.Gpa=g;
	}
	public static void main(String[] args) {
		List <Student> list=new ArrayList<Student>();
		Student S1=new Student(1, "Abad", 20, 3.5);
		Student S2=new Student(2, "Ali", 89, 2.5);
		Student S3=new Student(3, "Ahmad", 32, 4.0);
		Student S4=new Student(4, "Usman", 54, 2.3);
		Student S5=new Student(5, "Iqbal", 11, 2.7);
		list.add(S1);
		list.add(S2);
		list.add(S3);
		list.add(S4);
		list.add(S5);
		//now set the name of the last student 
		String Name="Abu Bakar";
		S5.name=Name;
		//getting gpa of 2nd student and assiging it in variable and printing
		double g=S2.Gpa;
		System.out.println("GPA of the 2nd Student is: "+g);
		list.remove(S3);
		for(Student s:list) {
		System.out.println(s);
		}
		
	}

}
//Create a class Student that has the following data members:
//id, name, roll_number, Gpa
// Create an array list of students.
// Add 5 students into that array list.
// Sets the name of the last student.
// Get 2 nd student’s Gpa and print it on screen.
// Delete 3 rd student from that list.
// Iterate the list using a for loop.