package i201815_Abad_Naseer_Q_SDA_Lab_02;

import java.util.ArrayList;
import java.util.List;

public class University {
	public Department Dept[]=new Department[20];
	public String UniName;
	public String Location;
	public University(String n, String l)
	{
		this.UniName=n;
		this.Location=l;
	}
	public void ShowRecord()
	{
		System.out.println("Departments of the University "+UniName+ " :");
		System.out.println(Dept[0].name);
		System.out.println(Dept[1].name);
	}
	
}