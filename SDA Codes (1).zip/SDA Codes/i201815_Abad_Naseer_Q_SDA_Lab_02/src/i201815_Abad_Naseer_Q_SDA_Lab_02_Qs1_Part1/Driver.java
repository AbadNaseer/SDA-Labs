package i201815_Abad_Naseer_Q_SDA_Lab_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Driver {

	public static void main(String[] args) {
		University U=new University("Fast", "H-11/2");
		Department D= new Department("CS");
		Department D1= new Department("SE");
		U.Dept[0]=D;
		U.Dept[1]=D1;
		Professor Prof=new Professor("Naveed Ahmad", "203-C");
		Professor Prof1=new Professor("Hammad Majeed", "501-B");
		U.Dept[0].P[0]=Prof;
		U.Dept[0].P[1]=Prof1;
		U.ShowRecord();
		U.Dept[0].ShowProf();
		//likely for professor 3, 4, 5 
		
	}

}
