package i201815_Abad_Naseer_Q_SDA_Lab_02;

public class Professor {
	public String Name;
	public String Office;
	public Department D;
	public Professor()
	{
		this.Name="";
		this.Office="";
	}
	public Professor(String n, String O)
	{
		this.Name=n;
		this.Office=O;
	}
}
