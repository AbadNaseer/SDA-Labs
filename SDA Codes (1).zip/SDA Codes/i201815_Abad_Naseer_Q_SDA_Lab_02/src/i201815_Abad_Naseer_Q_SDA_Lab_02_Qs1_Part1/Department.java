package i201815_Abad_Naseer_Q_SDA_Lab_02;

import java.util.ArrayList;

//class of department
public class Department {
public String name;
public Professor P[]=new Professor[5];
public Department()
{
	this.name="";
}
public Department(String n)
{
	this.name=n;
}
public void ShowProf()
{
	System.out.println("Professors of the Department are:");
	System.out.println(P[0].Name);
	System.out.println(P[1].Name);
}
}
